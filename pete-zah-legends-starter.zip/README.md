# Pete Zah Legends

A colorful, mobile-friendly arcade portal prototype with search, categories, favorites, mini-game prototypes, and an owner-panel UI for access requests and user actions.

## Deploy on GitHub Pages
1. Create a new GitHub repository (for example `pete-zah-legends`).
2. Upload `index.html` and this `README.md` to the repository root.
3. In **Settings → Pages**, choose **Deploy from a branch**, branch `main`, folder `/(root)`, and save.
4. Wait for GitHub Pages to publish.

## Important limitations
This is a **front-end demo**, not production authentication. The owner password, users, requests, and bans are stored in the browser's local storage. This does not securely identify the owner, share records across devices, revoke real sessions, or prevent banned visitors from opening the public GitHub Pages site. Do not use it as a real access-control system until you connect a backend (for example Supabase/Firebase) and enforce authorization server-side.

The initial catalog contains original mini-game prototypes and illustrative cover art, not 200 commercial/licensed games. Add games only when you have permission to host or embed them. Some external game and social-media providers block iframe embedding.

## Next production step
Connect authentication and a database; store users, access requests, bans, and sessions server-side; enforce banned status on every protected page/API; and add a catalog of distinct games with licenses that permit redistribution or approved embeds.
